int search(char *key, char *arr[], int arrLen);
int isPath(char *path);
void writeToFile(int inFile, int outFile);
int invalidFlagsExist(int argc, char *argv[]);
int main(int argc, char *argv[]);
